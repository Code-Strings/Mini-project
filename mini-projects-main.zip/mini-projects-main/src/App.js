import React, { useEffect, useState } from 'react';
import './App.css';
import LoginForm from "./Components/LoginForm";
import Alert from "react-bootstrap/Alert";
import { Button, Col, Row } from "react-bootstrap";
import AddressInfo from './Components/AddressInfo';
import Navbar from './Components/Navbar';

function App() {
  const userLogin = {
    user1:{
    ID: 1, 
    username: "user", 
    password: "User1Password" ,
    loggedin: false
    },
    user2:{ 
      ID: 2, 
      username: "user2", 
      password: "User2Password",
      loggedin: false
      }
}

const [user, setUser] = useState({ id:"",username: "", password: "", loggedin: false });
const [err, setError] = useState(true);

const Login = (Credentials, err) =>
{
  console.log("Credentials received: ",Credentials);
  console.log("userLogin details: ",userLogin);
  if (Credentials.username === "user"||Credentials.username === "user2" && 
  Credentials.password === "User1Password"||Credentials.password === "User2Password")
  {
    console.log(Credentials.username,"Logged in!");
    setUser({
      id:Credentials.ID,
      username: Credentials.username,
      password: Credentials.password,
      loggedin: true
    });
    console.log(user);
    {console.log("check==> " + user.loggedin)}
  }
  else
  {
    console.log("Credentials do not match!");
    setError(false);
    console.log(err);
  }
}

useEffect(() =>
{
  const loggedInUser = localStorage.getItem("user");
  if (loggedInUser)
  {
    const foundUser = (loggedInUser);
    setUser(foundUser);
  }
}, [user]);

const LogOut = () =>
{
  setUser({ username: "", password: "" });
  localStorage.clear();
}

    return (
        <div className="wrapper">
          {(user.loggedin) ? (
        <div className="home">
          <Row> <Col  style={{display:"flex"}}><Navbar logOut={LogOut}/><Button id="logout" onClick={LogOut}>Log Out</Button></Col></Row>
           
        <AddressInfo userId={user.id}/>
         
        </div>
      ) : (
        <div>
          <LoginForm Login={Login} error={err} />
          {err ? <p></p> : <Alert variant="danger" onClose={() => setError(true)} dismissible>
            <Alert.Heading>Error!</Alert.Heading>
            <p>
              entered user name or password is wrong!
              </p>
          </Alert>}
        </div>
      )}
       
      </div>
    )
}
export default App;