import axios from "axios";
import React, { useEffect, useState } from "react";
import { InputGroup, Modal, Card, Spinner, Form, Button } from "react-bootstrap";
import { FaEdit } from "react-icons/fa";
import { MdDelete } from "react-icons/md";

const baseURL = "http://localhost:3001/record/";
const myStore = window.localStorage;


const AddressInfo = (props) => {
  let ID = props.userId;
  const getURL = "http://localhost:3001/record/?OwnerId=" + ID;
  console.log(myStore);
  const [userData, setuserData] = useState([]);
  const [search, setSearch] = useState("");

  const [modalInsert, setModalInsert] = useState(false);
  const [modalUpdate, setModalUpdate] = useState(false);
  const [modalDelete, setModalDelete] = useState(false);

  const [userSelected, setuserSelected] = useState({
    id: "",
    First_Name: "",
    Last_Name: "",
    Birthday: "",
    Description: "",
    Phone_Number: "",
    Email: "",
    CreatedDate: new Date().toISOString(),
    UpdatedDate: "",
    OwnerId: props.userId
  });
  const handleChange = (e) => {
    const { name, value } = e.target;
    setuserSelected((prevState) => ({
      ...prevState,
      [name]: value,
    }));
  };

  const searchSpace = (e) => {
    let keyword = e.target.value;
    setSearch(keyword)
  }


  const OpenCloseModal = (type) => {
    switch (type) {
      case "INSERT":
        setModalInsert(!modalInsert);
        break;
      case "UPDATE":
        setModalUpdate(!modalUpdate);
        break;
      case "DELETE":
        setModalDelete(!modalDelete);
        break;
      default:
        break;
    }
  };

  const requestGET = async () => {
    await axios
      .get(getURL)
      .then((response) => {
        setuserData(response.data);
        console.log("get userData", userData);
      })
      .catch((error) => {
        console.log(error);
      });
  };

  const requestPOST = async () => {
    if (validated) {
      await axios.post(baseURL, userSelected).then((response) => {
        setuserData(userData.concat(response.data));
        OpenCloseModal("INSERT");
      });
      console.log("userSelected", userSelected);
      setValidated(false);
    }
  };

  const requestPUT = async () => {
    await axios
      .put(baseURL + userSelected.id, userSelected)
      .then((response) => {
        var newuserData = userData;
        newuserData.map((user) => {
          if (userSelected.id === user.id) {
            user.First_Name = userSelected.First_Name;
            user.Last_Name = userSelected.Last_Name;
            user.Birthday = userSelected.Birthday;
            user.Description = userSelected.Description;
            user.Phone_Number = userSelected.Phone_Number;
            user.Email = userSelected.Email;
            user.UpdatedDate = userSelected.UpdatedDate = new Date().toISOString();
            { console.log("date: ", user.UpdatedDate) }
          }
          return userSelected;
        });
        setuserData(newuserData);
        console.log(
          myStore.setItem("users", JSON.stringify(newuserData))
        );
        OpenCloseModal("UPDATE");
      });
  };

  const requestDEL = async () => {
    await axios.delete(baseURL + userSelected.id).then((response) => {
      setuserData(
        userData.filter((user) => user.id !== userSelected.id)
      );
      myStore.removeItem("user");
      OpenCloseModal("DELETE");
    });
  };

  const selectuser = (user, typeCase) => {
    setuserSelected(user);
    switch (typeCase) {
      case "Update":
        setModalUpdate(true);
        break;
      case "Delete":
        setModalDelete(true);
        break;
      default:
        break;
    }
  };

  useEffect(() => {
    requestGET();
  }, []);

  const [validated, setValidated] = useState(false);

  const handleSubmit = (event) => {
    const form = event.currentTarget;
    if (form.checkValidity() === false) {
      event.preventDefault();
      event.stopPropagation();
    }
    event.preventDefault();
    requestPOST();
    setValidated(true);
  };

  const userDataInsert = (
    <div className="d-flex justify-content-center align-items-center flex-column py-4">
      <div style={{ padding: "10px" }}><b>Add new user</b></div>
      <Form noValidate validated={validated} onSubmit={handleSubmit}>
        <InputGroup hasValidation>
          <Form.Group className="mb-3" controlId="validationCustom01">
            <Form.Control
              required
              aria-describedby="inputGroupPrepend"
              name="First_Name"
              type="text"
              placeholder="First Name"
              onChange={handleChange}
              value={userData.name}
            />
            <Form.Control.Feedback type="invalid">
              Please enter First Name.
            </Form.Control.Feedback>
          </Form.Group >
          <Form.Group className="mb-3" controlid="validationCustom02">
            <Form.Control
              required
              name="Last_Name"
              type="text"
              placeholder="Last Name"
              onChange={handleChange}
              value={userData.surname}
            />
            <Form.Control.Feedback type="invalid">
              Please enter Last Name.
            </Form.Control.Feedback>
          </Form.Group >
          <Form.Group className="mb-3" controlid="validationCustom03">
            <Form.Control
              required
              name="Birthday"
              type="date"
              placeholder="Birthday"
              onChange={handleChange}
              value={userData.birthday}
            />
            <Form.Control.Feedback type="invalid">
              Please enter Birthday.
            </Form.Control.Feedback>
          </Form.Group >
          <Form.Group className="mb-3" controlid="validationCustom04">
            <Form.Control
              required
              name="Description"
              type="text"
              placeholder="Description"
              onChange={handleChange}
              value={userData.description}
            />
            <Form.Control.Feedback type="invalid">
              Please enter Description.
            </Form.Control.Feedback>
          </Form.Group >
          <Form.Group className="mb-3" controlid="validationCustom05">
            <Form.Control
              required
              name="Phone_Number"
              type="text"
              placeholder="Phone Number"
              onChange={handleChange}
              value={userData.phone}
            />
            <Form.Control.Feedback type="invalid">
              Please enter Phone Number.
            </Form.Control.Feedback>
          </Form.Group >
          <Form.Group className="mb-3" controlid="formGroupAddress">
            <Form.Control
              required
              name="Email"
              type="text"
              placeholder="Email"
              onChange={handleChange}
              value={userData.email}
            />
            <Form.Control.Feedback type="invalid">
              Please enter Email.
            </Form.Control.Feedback>
          </Form.Group >
        </InputGroup>
        <div className="d-flex justify-content-center">
          <Button type="submit">Create</Button>
          <button type="button" className="btn btn-danger mx-3 w-50" onClick={() => OpenCloseModal("INSERT")}>
            Cancel
          </button>
        </div>
      </Form>
    </div>
  );

  const userDataUpdate = (
    <div className="d-flex justify-content-center align-items-center flex-column py-4">
      <div className="text-uppercase mb-4"><b>Edit user {userSelected.id}</b></div>
      <Form>
        <Form.Group className=" mb-3" controlid="formGroupName">
          <Form.Control required
            name="First_Name"
            type="text"
            placeholder="First Name"
            onChange={handleChange}
            value={userSelected && userSelected.First_Name}
          />
        </Form.Group>
        <Form.Group className=" mb-3" controlid="formGroupLastName">
          <Form.Control required
            name="Last_Name"
            type="text"
            placeholder="Last_Name"
            onChange={handleChange}
            value={userSelected && userSelected.Last_Name}
          />
        </Form.Group>
        <Form.Group className=" mb-3" controlid="formGroupTel">
          <Form.Control required
            name="Birthday"
            type="date"
            placeholder="Birthday"
            onChange={handleChange}
            value={userSelected && userSelected.Birthday}
          />
        </Form.Group>
        <Form.Group className=" mb-3" controlid="formGroupTel">
          <Form.Control required
            name="Description"
            type="text"
            placeholder="Description"
            onChange={handleChange}
            value={userSelected && userSelected.Description}
          />
        </Form.Group>
        <Form.Group className=" mb-3" controlid="formGroupTel">
          <Form.Control required
            name="Phone_Number"
            type="text"
            placeholder="Phone Number"
            onChange={handleChange}
            value={userSelected && userSelected.Phone_Number}
          />
        </Form.Group>
        <Form.Group className=" mb-3" controlid="formGroupAddress">
          <Form.Control required
            name="Email"
            type="text"
            placeholder="Email"
            onChange={handleChange}
            value={userSelected && userSelected.Email}
          />
        </Form.Group>
        <div className="d-flex justify-content-center">
          <button type="button" className="btn btn-success mx-3 w-50" onClick={() => requestPUT()}>
            Edit
          </button>
          <button type="button" className="btn btn-danger mx-3 w-50" onClick={() => OpenCloseModal("UPDATE")} >
            Cancel
          </button>
        </div>
      </Form>
    </div>
  );

  const userDataDelete = (
    <div className="p-4">
      <p>
        Do you want to delete user info for {" "}
        <b>{userSelected && userSelected.First_Name}</b> ?
      </p>

      <div className="d-flex justify-content-center">
        <button type="button" className="btn btn-success mx-3" onClick={() => requestDEL()}>
          Delete
        </button>
        <button type="button" className="btn btn-danger mx-3" onClick={() => OpenCloseModal("DELETE")}>
          Cancel
        </button>
      </div>
    </div>
  );

  const searchUser = userData.filter((data) => {
    if (search === "")
      return data
    else if (
      data.First_Name.toLowerCase().includes(search.toLowerCase()) ||
      data.Last_Name.toLowerCase().includes(search.toLowerCase()) ||
      data.Email.toLowerCase().includes(search.toLowerCase()) ||
      data.Phone_Number.toLowerCase().includes(search.toLowerCase())) {
      return data
    }
  }).map(user => {
    return (
      <div
        key={userData.id}
      >{console.log(user)}
        <Card>
          <div className="col-md-4 d-flex justify-content-center align-items-center flex-column">
            <img
              className="rounded w-50"
              alt="avatar"
              src="https://cdn-icons.flaticon.com/png/128/3177/premium/3177440.png?token=exp=1639847863~hmac=98a38595d6f7ba198520164c69a4c8ba"
            />
            <div >
              <button
                className="btn btn-primary"
                onClick={() => selectuser(user, "Update")}
              >
                <FaEdit />
              </button>
              <button
                className="btn btn-danger"
                onClick={() => selectuser(user, "Delete")}
              >
                <MdDelete />
              </button>
              <div className="mb-3"></div>
              <p id="create">Created on: {user.CreatedDate}</p>
              <p id="edit">Updated on: {user.UpdatedDate}</p>
            </div>
          </div>
          <div className="col-md-8">
            <div className="card-text">
              <ul className="list-group">
                <li className="list-group-item">
                  <b>First Name:</b> {user.First_Name}
                </li>
                <li className="list-group-item">
                  <b>Last Name:</b> {user.Last_Name}
                </li>
                <li className="list-group-item">
                  <b>Birthday:</b> {user.Birthday}
                </li>
                <li className="list-group-item">
                  <b>Description:</b> {user.Description}
                </li>
                <li className="list-group-item">
                  <b>Phone Number:</b> {user.Phone_Number}
                </li>
                <li className="list-group-item">
                  <b>Email:</b> {user.Email}
                </li>
              </ul>
            </div>
          </div>
        </Card>
      </div>
    )
  })


  return (
    <div className="container w-50">
      <button
        className="btn btn-primary btn-lg my-3"
        type="button"
        onClick={() => OpenCloseModal("INSERT")}
      >
        Add new user
      </button>
      <input className="form-control"
        name="Email"
        type="text"
        placeholder="Enter item to be searched"
        onChange={(e) => searchSpace(e)}
      />
      {/* <img
        style={{height:30,width:30}}
        src="https://cdn-icons.flaticon.com/png/128/3287/premium/3287968.png?token=exp=1639891759~hmac=9662daa14ee8706a4ef5034c482f7fa8" 
        alt="search"/> */}
      {(userData.length == 0) ?
        (<div>
          <Spinner animation="border" role="status">
            <span className="visually-hidden">Loading...</span>
          </Spinner>
          Loading....
        </div>) :
        <div>{searchUser}
        </div>
      }
      <Modal show={modalInsert} onHide={() => OpenCloseModal("INSERT")}>
        {userDataInsert}
      </Modal>
      <Modal show={modalUpdate} onHide={() => OpenCloseModal("UPDATE")}>
        {userDataUpdate}
      </Modal>
      <Modal show={modalDelete} onHide={() => OpenCloseModal("DELETE")}>
        {userDataDelete}
      </Modal>
    </div>
  );
};

export default AddressInfo;
