import React, { useState } from "react";
import { Form, Button, Container, Card } from "react-bootstrap";

function LoginForm({ Login }) {
    const [credentials, setCredentials] = useState({ ID:"",username: "", password: "" });

    const submitHandler = e => {
        e.preventDefault();
        Login(credentials);
    }

    return (

        <Container>
            <Card>
                <Form onSubmit={submitHandler}>
                    <h3>Login to store</h3>
                    <Form.Group controlId="formBasicEmail">
                        <Form.Label>User name</Form.Label>
                        <Form.Control type="text" placeholder="Enter email"
                            onChange={e => setCredentials({ ...credentials,username: e.target.value })}
                            value={credentials.username} />
                    </Form.Group>

                    <Form.Group controlId="formBasicPassword">
                        <Form.Label>Password</Form.Label>
                        <Form.Control type="password" placeholder="Password"
                            onChange={e => setCredentials({ ...credentials,ID:credentials.username === "user"?1:2,password: e.target.value })}
                            value={credentials.password} />
                    </Form.Group>
                    <div style={{ paddingTop: 10 }}>
                        <Button variant="primary" type="submit">
                            Login
                        </Button></div>
                </Form>
            </Card>
        </Container>

    )
}
export default LoginForm;