import React from "react";

const Navbar = ({LogOut}) => {
  return (
    <div className="container-fluid bg-dark d-flex justify-content-center">
      <div className="row">
        <h1 className="text-light" >User Address Book</h1>
      </div>
    </div>
  );
};

export default Navbar;
