//not used//
export function fetchUserData() {
    return fetch('http://localhost:3001/record')
      .then(data => data.json())
  }